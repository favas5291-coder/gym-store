Place clean, high-resolution product photos in this directory.

Use one product, one colour, one view, with a plain background. Do not use a
front/back collage, a size-chart graphic, or the same photo for every colour.
Use JPEG or PNG, at least 384 px on the shorter side and below 3 MiB.

Match each filename to config/virtual-try-on.json. Set approved to true only
after checking that the image shows that exact product and colour.
The server verifies that each approved file exists and has a valid image header.
Products without an approved photo remain selectable; generation is unavailable
for those colours, with an explanation shown to the customer.
