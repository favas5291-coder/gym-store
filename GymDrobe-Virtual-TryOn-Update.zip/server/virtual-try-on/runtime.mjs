import fs from "node:fs/promises";
import path from "node:path";
import { loadCatalog } from "./catalog.mjs";
import { createHandler } from "./handler.mjs";
import { memoryStore, redisStore } from "./store.mjs";
import { fashnProvider } from "./provider.mjs";
const root = process.cwd();
export async function createRuntime({ local = false } = {}) {
  const config = JSON.parse(
    await fs.readFile(path.join(root, "config/virtual-try-on.json"), "utf8"),
  );
  const catalog = await loadCatalog(root, config);
  const origin = local ? "http://localhost:5173" : process.env.VTO_APP_ORIGIN;
  const secret = process.env.VTO_SESSION_SECRET;
  const redisUrl = process.env.UPSTASH_REDIS_REST_URL,
    redisToken = process.env.UPSTASH_REDIS_REST_TOKEN;
  const store =
    redisUrl && redisToken
      ? redisStore({ url: redisUrl, token: redisToken })
      : local
        ? memoryStore()
        : null;
  const daily = Number(process.env.VTO_DAILY_LIMIT || 30);
  return createHandler({
    catalog,
    store,
    origin,
    secret,
    production: !local,
    provider: process.env.FASHN_API_KEY
      ? fashnProvider(process.env.FASHN_API_KEY)
      : null,
    limits: {
      visitor: 5,
      ip: 10,
      daily: Number.isSafeInteger(daily) && daily >= 0 ? daily : 30,
    },
  });
}
