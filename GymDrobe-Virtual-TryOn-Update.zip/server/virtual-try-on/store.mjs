// Redis stores short-lived job metadata and counters, never customer images.
// Atomic reservations work across simultaneous Vercel function instances.
const RESERVE = `
local previous=redis.call('GET',KEYS[1])
if previous then return {'existing',previous} end
if redis.call('EXISTS',KEYS[2])==1 then return {'busy'} end
for i=3,5 do
  if tonumber(redis.call('GET',KEYS[i]) or '0')>=tonumber(ARGV[i]) then return {'limit'} end
end
redis.call('SET',KEYS[1],ARGV[1],'EX',600)
redis.call('SET',KEYS[2],ARGV[2],'EX',240)
for i=3,5 do
  local n=redis.call('INCR',KEYS[i])
  if n==1 then redis.call('EXPIRE',KEYS[i],i==5 and 86400 or 3600) end
end
return {'created',ARGV[1]}`;
const UPDATE = `
local raw=redis.call('GET',KEYS[1]); if not raw then return nil end
local old=cjson.decode(raw)
if old.status=='cancelled' then return raw end
local patch=cjson.decode(ARGV[1]); for k,v in pairs(patch) do old[k]=v end
local value=cjson.encode(old);redis.call('SET',KEYS[1],value,'KEEPTTL');return value`;
const CANCEL = `
local raw=redis.call('GET',KEYS[1]);local job=raw and cjson.decode(raw) or {}
job.status='cancelled';redis.call('SET',KEYS[1],cjson.encode(job),'EX',600)
if redis.call('GET',KEYS[2])==ARGV[1] then redis.call('DEL',KEYS[2]) end
return 1`;
const RELEASE = `if redis.call('GET',KEYS[1])==ARGV[1] then return redis.call('DEL',KEYS[1]) end return 0`;
const COUNT = `local n=redis.call('INCR',KEYS[1]);if n==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]) end return n`;
const key = (owner, id) => `gd:vto:job:${owner}:${id}`;
const active = (owner) => `gd:vto:active:${owner}`;

export function redisStore({ url, token, fetchImpl = fetch }) {
  if (!/^https:\/\/[^/]+\.upstash\.io\/?$/.test(url || ""))
    throw new Error("Use your Upstash Redis HTTPS REST URL.");
  async function command(...args) {
    const response = await fetchImpl(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(args),
      signal: AbortSignal.timeout(10000),
      redirect: "error",
    });
    if (!response.ok) throw new Error("Job storage unavailable");
    const data = await response.json();
    if (data.error) throw new Error("Job storage unavailable");
    return data.result;
  }
  return {
    async reserve(owner, ip, id, job, limits) {
      const result = await command(
        "EVAL",
        RESERVE,
        5,
        key(owner, id),
        active(owner),
        `gd:vto:user:${owner}`,
        `gd:vto:ip:${ip}`,
        "gd:vto:daily",
        JSON.stringify(job),
        id,
        limits.visitor,
        limits.ip,
        limits.daily,
      );
      return {
        state: result[0],
        job: result[1] ? JSON.parse(result[1]) : null,
      };
    },
    async get(owner, id) {
      const raw = await command("GET", key(owner, id));
      return raw ? JSON.parse(raw) : null;
    },
    async update(owner, id, patch) {
      const raw = await command(
        "EVAL",
        UPDATE,
        1,
        key(owner, id),
        JSON.stringify(patch),
      );
      return raw ? JSON.parse(raw) : null;
    },
    cancel: (owner, id) =>
      command("EVAL", CANCEL, 2, key(owner, id), active(owner), id),
    release: (owner, id) => command("EVAL", RELEASE, 1, active(owner), id),
    async throttle(ip) {
      return (
        Number(await command("EVAL", COUNT, 1, `gd:vto:http:${ip}`, 60)) <= 120
      );
    },
    async poll(owner, id) {
      return (
        (await command(
          "SET",
          `gd:vto:poll:${owner}:${id}`,
          "1",
          "NX",
          "EX",
          2,
        )) === "OK"
      );
    },
  };
}

// Development/test only. Production refuses this adapter.
export function memoryStore(now = () => Date.now()) {
  const records = new Map();
  const get = (k) => {
    const v = records.get(k);
    if (!v || v.expires <= now()) {
      records.delete(k);
      return null;
    }
    return v.value;
  };
  const set = (k, value, seconds) =>
    records.set(k, { value, expires: now() + seconds * 1000 });
  function count(k, ttl) {
    const n = (get(k) || 0) + 1;
    if (n === 1) set(k, n, ttl);
    else records.get(k).value = n;
    return n;
  }
  return {
    async reserve(owner, ip, id, job, limits) {
      for (const k of records.keys()) get(k);
      const previous = get(key(owner, id));
      if (previous) return { state: "existing", job: { ...previous } };
      if (get(active(owner))) return { state: "busy" };
      const keys = [`u:${owner}`, `i:${ip}`, "daily"];
      if (
        keys.some(
          (k, i) =>
            (get(k) || 0) >= [limits.visitor, limits.ip, limits.daily][i],
        )
      )
        return { state: "limit" };
      keys.forEach((k, i) => count(k, i === 2 ? 86400 : 3600));
      set(key(owner, id), { ...job }, 600);
      set(active(owner), id, 240);
      return { state: "created", job: { ...job } };
    },
    async get(owner, id) {
      const v = get(key(owner, id));
      return v ? { ...v } : null;
    },
    async update(owner, id, patch) {
      const job = get(key(owner, id));
      if (!job) return null;
      if (job.status !== "cancelled") Object.assign(job, patch);
      return { ...job };
    },
    async cancel(owner, id) {
      set(
        key(owner, id),
        { ...(get(key(owner, id)) || {}), status: "cancelled" },
        600,
      );
      if (get(active(owner)) === id) records.delete(active(owner));
    },
    async release(owner, id) {
      if (get(active(owner)) === id) records.delete(active(owner));
    },
    async throttle(ip) {
      return count(`http:${ip}`, 60) <= 120;
    },
    async poll(owner, id) {
      const k = `poll:${owner}:${id}`;
      if (get(k)) return false;
      set(k, true, 2);
      return true;
    },
  };
}
