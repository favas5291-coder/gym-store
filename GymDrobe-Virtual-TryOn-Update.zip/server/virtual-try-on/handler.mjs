import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { VtoError, validateImage } from "./image.mjs";
const ID = /^[a-zA-Z0-9-]{16,80}$/;
const MAX_BODY = 2300000;
const same = (a, b) =>
  typeof a === "string" &&
  typeof b === "string" &&
  Buffer.byteLength(a) === Buffer.byteLength(b) &&
  timingSafeEqual(Buffer.from(a), Buffer.from(b));
export function createHandler({
  catalog,
  provider,
  store,
  secret,
  origin,
  production = false,
  now = () => Date.now(),
  limits = { visitor: 5, ip: 10, daily: 30 },
}) {
  const configured = Boolean(
    provider && store && secret?.length >= 32 && origin,
  );
  const cookieName = production ? "__Host-gd-vto" : "gd-vto";
  const hmac = (value) =>
    createHmac("sha256", secret).update(value).digest("hex");
  const json = (res, status, data) => {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store, private",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
    });
    res.end(JSON.stringify(data));
  };
  function session(req, res, create = false) {
    const cookie = String(req.headers.cookie || "")
      .split(";")
      .map((v) => v.trim())
      .find((v) => v.startsWith(cookieName + "="))
      ?.slice(cookieName.length + 1);
    const parts = cookie?.split(".") || [];
    let sid;
    if (
      parts.length === 3 &&
      /^[a-f0-9]{48}$/.test(parts[0]) &&
      /^\d{13}$/.test(parts[1]) &&
      Number(parts[1]) > now() &&
      same(parts[2], hmac(parts[0] + "." + parts[1]))
    )
      sid = parts[0];
    if (!sid) {
      if (!create)
        throw new VtoError(
          401,
          "Please reopen Virtual Try-On to start a new session.",
          "SESSION_EXPIRED",
        );
      sid = randomBytes(24).toString("hex");
      const value = sid + "." + (now() + 86400000);
      res.setHeader(
        "Set-Cookie",
        `${cookieName}=${value}.${hmac(value)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${production ? "; Secure" : ""}`,
      );
    }
    return { owner: hmac("owner:" + sid), csrf: hmac("csrf:" + sid) };
  }
  async function body(req) {
    if (
      !String(req.headers["content-type"] || "").startsWith("application/json")
    )
      throw new VtoError(415, "The photo request could not be read.");
    if (Number(req.headers["content-length"] || 0) > MAX_BODY)
      throw new VtoError(413, "Choose a smaller photo.", "PHOTO_TOO_LARGE");
    if (req.body !== undefined) {
      const value =
        typeof req.body === "string" ? JSON.parse(req.body) : req.body;
      if (Buffer.byteLength(JSON.stringify(value)) > MAX_BODY)
        throw new VtoError(413, "Choose a smaller photo.", "PHOTO_TOO_LARGE");
      return value;
    }
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_BODY)
        throw new VtoError(413, "Choose a smaller photo.", "PHOTO_TOO_LARGE");
      chunks.push(Buffer.from(chunk));
    }
    try {
      return JSON.parse(Buffer.concat(chunks).toString());
    } catch {
      throw new VtoError(400, "The photo request could not be read.");
    }
  }
  return async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost"),
        action = url.searchParams.get("action");
      if (url.pathname !== "/api/virtual-try-on")
        return json(res, 404, { message: "Not found." });
      if (!["GET", "POST", "DELETE"].includes(req.method))
        throw new VtoError(405, "Method not allowed.");
      if (
        req.headers["sec-fetch-site"] === "cross-site" ||
        (req.headers.origin && req.headers.origin !== origin)
      )
        throw new VtoError(403, "Open Virtual Try-On from GymDrobe.");
      if (req.method !== "GET" && req.headers.origin !== origin)
        throw new VtoError(403, "Please reopen Virtual Try-On.");
      if (origin && String(req.headers.host) !== new URL(origin).host)
        throw new VtoError(403, "Unexpected request host.");
      if (!configured) {
        if (req.method === "GET" && action === "config")
          return json(res, 200, {
            configured: false,
            products: catalog.products,
            csrf: "",
          });
        throw new VtoError(
          503,
          "Photo try-on is being set up. You can still explore products and choose your size.",
          "NOT_CONFIGURED",
        );
      }
      // Vercel overwrites this header. Local development ignores client-supplied forwarding headers.
      const address = production
        ? String(
            req.headers["x-vercel-forwarded-for"] ||
              req.headers["x-forwarded-for"] ||
              "unknown",
          )
        : String(req.socket?.remoteAddress || "local");
      const ip = hmac("ip:" + address);
      if (!(await store.throttle(ip)))
        throw new VtoError(
          429,
          "Please slow down and try again in a minute.",
          "RATE_LIMIT",
        );
      const { owner, csrf } = session(
        req,
        res,
        req.method === "GET" && action === "config",
      );
      if (req.method !== "GET" && !same(req.headers["x-gymdrobe-token"], csrf))
        throw new VtoError(
          403,
          "Please reopen Virtual Try-On and try again.",
          "SESSION_EXPIRED",
        );
      if (req.method === "GET" && action === "config")
        return json(res, 200, {
          configured: true,
          products: catalog.products,
          csrf,
        });
      const id = url.searchParams.get("id");
      if (req.method === "POST" && action === "generate") {
        const input = await body(req);
        if (!input || Array.isArray(input) || typeof input !== "object")
          throw new VtoError(400, "The photo request could not be read.");
        if (input.consent !== true)
          throw new VtoError(
            400,
            "Please agree to photo processing before continuing.",
            "CONSENT_REQUIRED",
          );
        if (typeof input.requestKey !== "string" || !ID.test(input.requestKey))
          throw new VtoError(400, "Please try starting a new preview.");
        const productImage = catalog.assets.get(
          JSON.stringify([String(input.productId), String(input.color || "")]),
        );
        if (!productImage)
          throw new VtoError(
            422,
            "A try-on photo is not available for this colour. Choose another colour or product.",
            "PRODUCT_UNAVAILABLE",
          );
        validateImage(input.personImage, { maxBytes: 1600000 });
        const job = {
          id: input.requestKey,
          productId: String(input.productId),
          color: String(input.color || ""),
          created: now(),
          status: "starting",
        };
        const reserved = await store.reserve(owner, ip, job.id, job, limits);
        if (reserved.state === "busy")
          throw new VtoError(
            409,
            "Your previous preview is still processing. Please wait or stop it first.",
            "BUSY",
          );
        if (reserved.state === "limit")
          throw new VtoError(
            429,
            "The try-on limit has been reached. Please try again later.",
            "RATE_LIMIT",
          );
        if (reserved.state === "existing")
          return json(res, 202, { id: job.id, status: reserved.job.status });
        // Await provider submission before returning: no background work after a serverless response.
        try {
          const providerId = await provider.start(
            input.personImage,
            productImage,
          );
          const saved = await store.update(owner, job.id, {
            providerId,
            status: "in_queue",
          });
          return json(res, 202, {
            id: job.id,
            status: saved?.status || "cancelled",
          });
        } catch (error) {
          await store.update(owner, job.id, {
            status: "failed",
            code: "GENERATION_FAILED",
            message:
              "The preview could not be started. Please try again later.",
          });
          await store.release(owner, job.id);
          throw error;
        }
      }
      if (!ID.test(id || ""))
        throw new VtoError(400, "This preview link is invalid.");
      if (req.method === "DELETE" && action === "job") {
        await store.cancel(owner, id);
        return json(res, 200, { removed: true });
      }
      if (req.method === "GET" && action === "job") {
        let job = await store.get(owner, id);
        if (!job || job.status === "cancelled")
          throw new VtoError(
            410,
            "This preview was removed or has expired.",
            "EXPIRED",
          );
        if (now() - job.created > 240000) {
          await store.release(owner, id);
          throw new VtoError(
            408,
            "This preview took too long. Please try again later.",
            "TIMEOUT",
          );
        }
        if (job.status === "failed")
          return json(res, 200, {
            status: "failed",
            message: job.message,
            code: job.code,
          });
        if (!job.providerId || !(await store.poll(owner, id)))
          return json(res, 200, { status: "processing" });
        const result = await provider.status(job.providerId);
        // A concurrent close/delete must never resurrect a removed result.
        job = await store.get(owner, id);
        if (!job || job.status === "cancelled")
          throw new VtoError(410, "This preview was removed.", "EXPIRED");
        if (result.status === "completed" || result.status === "failed") {
          await store.release(owner, id);
          if (result.status === "failed") await store.update(owner, id, result);
        }
        return json(res, 200, {
          ...result,
          productId: job.productId,
          color: job.color,
        });
      }
      throw new VtoError(404, "Not found.");
    } catch (error) {
      if (!res.headersSent)
        json(res, error instanceof VtoError ? error.status : 503, {
          code: error instanceof VtoError ? error.code : "SERVICE_UNAVAILABLE",
          message:
            error instanceof VtoError
              ? error.message
              : "The fitting room is temporarily unavailable. Please try again later.",
        });
      else res.end();
    }
  };
}
