import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

const script = new URL("../scripts/install-vto.mjs", import.meta.url);
async function fixture(t, legacy = false) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), "gymdrobe-vto-"));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const write = async (name, value) => {
    await fs.mkdir(path.dirname(path.join(root, name)), { recursive: true });
    await fs.writeFile(path.join(root, name), value);
  };
  const required = ["src/context/StoreContext.jsx", "src/context/CatalogContext.jsx", "src/components/Modal.jsx", "src/components/StorefrontShared.jsx", "src/components/virtual-try-on/VirtualTryOnButton.jsx", "api/virtual-try-on.js", "config/virtual-try-on.json"];
  for (const name of required) await write(name, "{}");
  await write("scripts/install-vto.mjs", await fs.readFile(script));
  await write("package.json", JSON.stringify({ type: "module", dependencies: { react: "19.1.1" }, scripts: { build: "vite build", prebuild: "node existing-setup.mjs" } }));
  await write("vite.config.js", legacy ? 'export default defineConfig({server: {proxy: {"/api/try-on": {target:"http://localhost:3001"}}}, plugins:[react()]});' : 'export default defineConfig({ plugins: [react()] });');
  await write("src/components/ProductOptions.jsx", `${legacy ? 'import TryOnEntry from "./tryon/TryOnEntry.jsx";\n' : ""}export default function ProductOptions(){
    const [size,setSize]=useState("M"), [color,setColor]=useState("Black"), [quantity,setQuantity]=useState(1), [added,setAdded]=useState(false);
    return <div>
      ${legacy ? '<TryOnEntry product={product} color={color} size={size} onSelectSize={next => { setSize(next); setQuantity(1); setAdded(false); }} />' : ""}
      <div className="quantity-line">Original purchase controls</div>
    </div>;
  }`);
  return { root, write, read: name => fs.readFile(path.join(root,name),"utf8"), run: () => spawnSync(process.execPath,[path.join(root,"scripts/install-vto.mjs")],{encoding:"utf8",cwd:root}) };
}
for (const legacy of [false,true]) test(`installer preserves existing controls/hooks and is idempotent (${legacy ? "previous try-on" : "original project"})`, async t => {
  const f=await fixture(t,legacy), original=await f.read("src/components/ProductOptions.jsx");
  const first=f.run(); assert.equal(first.status,0,first.stderr);
  const options=await f.read("src/components/ProductOptions.jsx");
  assert.equal((options.match(/<VirtualTryOnButton/g)||[]).length,1);
  assert.ok(options.includes("Original purchase controls")); assert.ok(!options.includes("TryOnEntry"));
  const pkg=JSON.parse(await f.read("package.json"));
  assert.equal(pkg.scripts.prebuild,"node existing-setup.mjs && node scripts/setup-vto.mjs");
  assert.equal(pkg.scripts.build,"vite build");
  const backup=(await fs.readdir(path.join(f.root,"vto-backup")))[0];
  assert.equal(await f.read(`vto-backup/${backup}/src/components/ProductOptions.jsx`),original);
  const names=["package.json","vite.config.js","vercel.json","src/components/ProductOptions.jsx",".gitignore"];
  const before=await Promise.all(names.map(f.read)); const second=f.run(); assert.equal(second.status,0,second.stderr);
  assert.deepEqual(await Promise.all(names.map(f.read)),before);
});
test("installer leaves every file untouched when integration is unfamiliar", async t => {
  const f=await fixture(t); await f.write("vite.config.js","export default buildMyConfig();");
  const names=["package.json","vite.config.js","src/components/ProductOptions.jsx"],before=await Promise.all(names.map(f.read));
  assert.equal(f.run().status,1); assert.deepEqual(await Promise.all(names.map(f.read)),before);
  await assert.rejects(fs.stat(path.join(f.root,"vto-backup")),{code:"ENOENT"});
});
