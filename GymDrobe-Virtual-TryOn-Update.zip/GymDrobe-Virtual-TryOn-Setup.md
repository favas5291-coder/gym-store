# GymDrobe Virtual Try-On — added files and integration edits

This update adds a visible **Virtual Try-On** button to your existing product controls and a responsive fitting room. It is written for the GymDrobe project with `ProductOptions.jsx`, `StoreContext.jsx` and `CatalogContext.jsx` that you shared. It does not replace your homepage, shopping cart, checkout or whole project.

The real image-generation adapter uses **FASHN Try-On Max**. Photo preparation and person checks run locally with MediaPipe. An API key, generation credits and accurate product photos are required to generate real previews. No simulated image is used as a production result.

## 1. Add the code

1. Stop your running development server with **Ctrl+C**.
2. Extract **GymDrobe-Virtual-TryOn-Update.zip** into your existing project root, the folder containing `package.json`. The extracted `src`, `api`, `server`, `public`, `config`, `scripts` and `tests` folders should merge with those folders in your project.
3. In that folder, run:

```bash
node scripts/install-vto.mjs
npm install
npm run setup:vto
npm run dev:vto
```

Open **http://localhost:5173/product/1**. The **Virtual Try-On** button appears near the size and quantity controls. Product 2 is also enabled. Other product IDs can be enabled in the configuration when you have suitable images.

Use Node **22.12 or newer**, as required by your current Vite project. `npm run dev:vto` starts both Vite and the local try-on API. A plain `npm run dev` does not start the new API.

The installer backs up the existing files it edits inside `vto-backup/`. It changes only `ProductOptions.jsx`, the relevant package scripts/dependency, the Vite proxy, Vercel function settings and ignore entries. It preserves existing package scripts and stops before writing if it cannot recognize the integration points. Running it again does not add duplicate buttons. `npm install` updates your existing lockfile.

You can open the fitting room before configuring AI. Generation will show an availability message until the API key and product images are ready.

## 2. Add exact-colour product photos

The initial product IDs match your T-shirt (`1`) and shoes (`2`). Confirm they still match your catalogue.

Add your photos inside `public/tryon-products/`:

| Product | Colour | Filename |
|---|---|---|
| T-shirt | Black | `tshirt-black.jpg` |
| T-shirt | White | `tshirt-white.jpg` |
| T-shirt | Blue | `tshirt-blue.jpg` |
| Shoes | Black | `shoes-black.jpg` |
| Shoes | White | `shoes-white.jpg` |
| Shoes | Grey | `shoes-grey.jpg` |

Use a sharp JPEG or PNG of the actual product and selected colour, at least 384 pixels on each side and smaller than 3 MiB. Use one clear view, without a front/back collage, watermarks or competing products. Do not reuse the black product image for a white or blue option.

In `config/virtual-try-on.json`, change `"approved": false` to `"approved": true` only for the colour whose correct image you have added. For example, the Black entry for product `1` becomes:

```json
"Black": {
  "image": "/tryon-products/tshirt-black.jpg",
  "approved": true
}
```

You can start with one approved colour. Unprepared colours remain available for ordinary shopping but cannot generate a misleading try-on. Restart the local API after changing the configuration or product images. Redeploy after changing them on Vercel.

## 3. Enable real AI generation locally

Get a server API key from your [FASHN account](https://fashn.ai/). Add it to the `.env` file in your project root; `.env.vto.example` lists the settings. Merge these with any existing `.env` values rather than deleting them.

```dotenv
FASHN_API_KEY=your_real_server_api_key
VTO_DAILY_LIMIT=30
```

Do not put the key in React components or in a variable starting with `VITE_`. Never commit `.env`.

Restart `npm run dev:vto`. The local runner uses a temporary signed session and in-memory job storage if Redis is absent. This fallback is for local development only; its counters reset when restarted.

Upload a well-lit photo of one fully clothed person. Include shoulders and hips for tops and both feet for shoes. Accept the photo-processing notice, then press **Try It On**. Generation requires available provider credits.

## 4. Enable the API on your Vercel website

The new `api/virtual-try-on.js` is the Vercel server function. Uploading React files alone will not enable image generation.

Create an [Upstash Redis database](https://console.upstash.com/) for expiring job metadata and request limits. Then add these **server environment variables** to the Vercel project:

| Variable | Value |
|---|---|
| `FASHN_API_KEY` | Your FASHN server API key |
| `VTO_SESSION_SECRET` | A random secret of at least 32 characters |
| `VTO_APP_ORIGIN` | `https://gym-store-xi.vercel.app` — no trailing slash |
| `UPSTASH_REDIS_REST_URL` | The database's HTTPS REST URL |
| `UPSTASH_REDIS_REST_TOKEN` | The database's REST token |
| `VTO_DAILY_LIMIT` | `30`, or a submission cap you choose; `0` pauses generation |

Create the session secret on your own computer:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Commit the added files, integration changes, your approved product photos and updated `package-lock.json`, then redeploy your Vercel project. Keep the build command **npm run build**; the `prebuild` hook prepares the photo-check assets. The production API refuses paid requests if its session or Redis configuration is missing.

Use the exact configured hostname when testing. If you use a custom domain or a separate preview deployment, set `VTO_APP_ORIGIN` for that environment to its exact origin. A different hostname is intentionally rejected.

The API uses a signed HttpOnly session, CSRF validation, owner-bound jobs, server-approved garment photos and atomic submission limits. Default limits are 5 submissions per visitor per hour, 10 per requesting IP per hour and 30 across the store per rolling 24 hours. Job metadata expires after 10 minutes; photos are not written to Redis. These limits reduce accidental and automated costs, but are not a replacement for monitoring provider usage.

## Included behaviour

- Prominent product-page entry and keyboard-accessible modal.
- Upload or device camera; camera tracks stop when the camera closes or the page becomes hidden.
- Local resolution, lighting, blur and pose checks, including no person / multiple people errors. Automated checks can make mistakes.
- Product selector, exact-colour availability, sizes and stock-aware Add to Cart using your existing store context.
- AI loading animation, cancellation and friendly provider errors.
- Before/after slider, download, native file sharing where supported and a download fallback elsewhere.
- Photo consent, a linked privacy notice and in-memory photo cleanup on close.
- Responsive layouts checked at 320, 390, 768 and 1440 pixels.

The preview illustrates appearance. Changing size selects the cart variant; it does **not** create a measured simulation of tightness or physical fit. Your size guide remains available. AI can alter face, pose, skin tone, body proportions, logos or garment details despite preservation instructions; evaluate real outputs before making claims about accuracy.

The provided photo notice describes this integration and FASHN's documented processing. Read it alongside your existing privacy policy before publishing. A submitted AI request may continue after the customer closes the modal; local cancellation does not promise deletion from the provider.

## Tests

```bash
npm run test:vto
npm run build
```

Browser checks are optional for development:

```bash
npm install --save-dev playwright
npx playwright install chromium
npm run test:vto:browser
```

The supplied browser suite uses a **mock AI provider and synthetic images**, tests the camera with a fake device, and checks upload/errors, consent, comparison, sharing, cancellation, cart variants and responsive layout. It also loads the real MediaPipe worker for a no-person check. Unit tests cover session ownership, duplicate requests, rate limits, cancellation, expiry, provider requests and installer safety. No API key was provided, so paid AI output quality, real Upstash connectivity and a live Vercel deployment were not validated here. Run a real end-to-end generation after configuring your account.

## Manual integration, if you prefer to make the edits yourself

Extract the new files first. The installer performs these edits; do not add a second button if you already ran it.

**`src/components/ProductOptions.jsx`** — add this import, replacing the old `TryOnEntry` import if present:

```jsx
import VirtualTryOnButton from "./virtual-try-on/VirtualTryOnButton.jsx";
```

Replace the old `<TryOnEntry ... />`, or insert immediately before `<div className="quantity-line">`:

```jsx
<VirtualTryOnButton
  product={product}
  color={color}
  size={size}
  onSelectionChange={({ color: nextColor, size: nextSize }) => {
    setColor(nextColor);
    setSize(nextSize);
    setQuantity(1);
    setAdded(false);
  }}
/>
```

**`package.json`** — add dependency `"@mediapipe/tasks-vision": "1.0.1"`. Add these scripts to the existing `scripts` object, preserving other entries:

```json
"setup:vto": "node scripts/setup-vto.mjs",
"dev:vto": "node scripts/dev-vto.mjs",
"prebuild": "node scripts/setup-vto.mjs",
"test:vto": "node --test tests/vto*.test.js",
"test:vto:browser": "node tests/vto-browser.mjs"
```

If you already have a `prebuild` command, append ` && node scripts/setup-vto.mjs` to it instead of replacing it.

**`vite.config.js`** — add to `server.proxy`:

```js
"/api/virtual-try-on": {
  target: "http://127.0.0.1:3001",
  changeOrigin: false,
},
```

**`vercel.json`** — merge this entry into `functions`:

```json
"api/virtual-try-on.js": {
  "maxDuration": 60,
  "includeFiles": "{config/virtual-try-on.json,public/tryon-products/**}"
}
```

For a project with no existing routing configuration, add `"rewrites": [{ "source": "/((?!api/).*)", "destination": "/index.html" }]`. Preserve any other routing rules and ensure `/api/virtual-try-on` reaches the function. The installer stops if it encounters legacy `routes` that need a manual merge.

**`.gitignore`** — add `.env`, `.env.local`, `vto-backup/`, `public/vto-assets/wasm/`, `public/vto-assets/vision_bundle.js`, `public/vto-assets/MEDIAPIPE-README.md`, `public/vto-assets/pose_landmarker_lite.task`, and `public/vto-assets/*.tmp`. Keep **`public/vto-assets/check-photo.worker.js`** tracked; the other model/runtime assets are generated during setup/build.

Then run `npm install`, `npm run setup:vto`, and `npm run dev:vto`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Button missing | Run the installer and check the product ID has `enabled: true` in the new configuration. On Vercel, redeploy the changes. |
| Photo check cannot load | Run `npm run setup:vto`. Check that `/vto-assets/check-photo.worker.js` and the generated model/runtime assets load successfully. |
| AI unavailable | Check the server key, credits and production Redis/session/origin values, then restart/redeploy. |
| Colour unavailable | Add the exact-colour photo and set its `approved` flag, then restart/redeploy. |
| Camera permission denied | Enable camera access in browser settings or upload a photo. Camera access requires HTTPS or localhost. |
| Share unavailable | Download the result. Native file sharing depends on browser/device support. |
| Port 5173 or 3001 in use | Stop the existing development server, then run only `npm run dev:vto`. |
| Windows `EPERM` during install | Stop running Vite/Node terminals first. Retry `npm install`; the update does not require deleting your project or lockfile. |

## API and model references

- [FASHN Try-On Max API](https://docs.fashn.ai/api-reference/tryon-max)
- [FASHN data retention and privacy](https://docs.fashn.ai/api-overview/data-retention-privacy)
- [MediaPipe Pose Landmarker for web](https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker/web_js)
- [Upstash Redis REST API](https://upstash.com/docs/redis/features/restapi)
- [Vercel project configuration](https://vercel.com/docs/project-configuration)

Update prepared 28 September 2026. This package contains additions and targeted integration edits, not a new complete storefront.
