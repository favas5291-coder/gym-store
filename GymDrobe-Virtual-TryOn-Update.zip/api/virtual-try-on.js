import { createRuntime } from "../server/virtual-try-on/runtime.mjs";
export const maxDuration = 60;
let runtime;
export default async function handler(request, response) {
  try {
    runtime ||= createRuntime();
    await (
      await runtime
    )(request, response);
  } catch {
    runtime = null;
    response.setHeader("Cache-Control", "no-store");
    response.statusCode = 503;
    response.setHeader("Content-Type", "application/json");
    response.end(
      JSON.stringify({
        code: "SERVICE_UNAVAILABLE",
        message:
          "The fitting room is temporarily unavailable. Please try again later.",
      }),
    );
  }
}
