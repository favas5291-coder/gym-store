import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);
const source = path.dirname(require.resolve("@mediapipe/tasks-vision"));
const destination = path.join(root, "public/vto-assets");
await fs.mkdir(destination, { recursive: true });
await fs.copyFile(
  path.join(source, "vision_bundle.js"),
  path.join(destination, "vision_bundle.js"),
);
await fs.copyFile(
  path.join(source, "README.md"),
  path.join(destination, "MEDIAPIPE-README.md"),
);
await fs.cp(path.join(source, "wasm"), path.join(destination, "wasm"), {
  recursive: true,
});
const model = path.join(destination, "pose_landmarker_lite.task");
try {
  if ((await fs.stat(model)).size > 1000000) {
    console.log("Virtual Try-On photo-check assets ready.");
    process.exit(0);
  }
} catch {}
const url =
  "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task";
const response = await fetch(url, { signal: AbortSignal.timeout(60000) });
if (!response.ok)
  throw new Error(
    "The photo-check model could not be downloaded. Run npm run setup:vto again.",
  );
const bytes = new Uint8Array(await response.arrayBuffer());
if (bytes.length < 1000000 || bytes.length > 15000000)
  throw new Error("Unexpected photo-check model download.");
await fs.writeFile(model + ".tmp", bytes);
await fs.rename(model + ".tmp", model);
console.log("Virtual Try-On photo-check assets ready.");
