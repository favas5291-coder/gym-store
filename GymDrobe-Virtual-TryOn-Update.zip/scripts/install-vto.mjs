import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Applies only the integration edits. No dependencies are installed by this script.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const edits = [];
async function read(name, optional = false) {
  try { return await fs.readFile(path.join(root, name), "utf8"); }
  catch (error) { if (optional && error.code === "ENOENT") return null; throw error; }
}
function change(name, before, after) {
  if (before !== after) edits.push({ name, before, after });
}
const button = `      <VirtualTryOnButton
        product={product}
        color={color}
        size={size}
        onSelectionChange={({ color: nextColor, size: nextSize }) => {
          setColor(nextColor);
          setSize(nextSize);
          setQuantity(1);
          setAdded(false);
        }}
      />`;

try {
  for (const name of [
    "src/context/StoreContext.jsx", "src/context/CatalogContext.jsx",
    "src/components/Modal.jsx", "src/components/StorefrontShared.jsx",
    "src/components/virtual-try-on/VirtualTryOnButton.jsx",
    "api/virtual-try-on.js", "config/virtual-try-on.json",
  ]) await fs.access(path.join(root, name));

  const beforeOptions = await read("src/components/ProductOptions.jsx");
  let options = beforeOptions;
  if (!options.includes("<VirtualTryOnButton")) {
    for (const state of ["setColor", "setSize", "setQuantity", "setAdded"])
      if (!options.includes(state)) throw new Error(`ProductOptions.jsx is missing ${state}. Use the manual integration in the setup guide.`);
    options = options.replace(/^import\s+TryOnEntry\s+from\s+["']\.\/tryon\/TryOnEntry(?:\.jsx)?["'];?\s*\r?\n/m, "");
    const oldButtons = options.match(/<TryOnEntry\b[\s\S]*?\/>/g) || [];
    if (oldButtons.length > 1) throw new Error("Multiple old try-on buttons found. Use the manual integration in the setup guide.");
    options = options.replace(/^[ \t]*<TryOnEntry\b[\s\S]*?\/>\s*\r?\n/m, "");
    const anchor = /^([ \t]*)<div className=["']quantity-line["']>/m;
    if (!anchor.test(options) || options.includes("TryOnEntry")) throw new Error("The product controls differ from the supplied version. Use the manual integration in the setup guide.");
    options = options.replace(anchor, `${button}\n$&`);
    if (!/import\s+VirtualTryOnButton\b/.test(options))
      options = `import VirtualTryOnButton from "./virtual-try-on/VirtualTryOnButton.jsx";\n${options}`;
  }
  change("src/components/ProductOptions.jsx", beforeOptions, options);

  const beforePackage = await read("package.json"), pkg = JSON.parse(beforePackage);
  if (pkg.type !== "module" || !pkg.dependencies?.react) throw new Error("This update expects the GymDrobe React ES-module project.");
  pkg.dependencies["@mediapipe/tasks-vision"] = "1.0.1";
  pkg.scripts ||= {};
  Object.assign(pkg.scripts, {
    "setup:vto": "node scripts/setup-vto.mjs",
    "dev:vto": "node scripts/dev-vto.mjs",
    "test:vto": "node --test tests/vto*.test.js",
    "test:vto:browser": "node tests/vto-browser.mjs",
  });
  if (!pkg.scripts.prebuild?.includes("scripts/setup-vto.mjs"))
    pkg.scripts.prebuild = [pkg.scripts.prebuild, "node scripts/setup-vto.mjs"].filter(Boolean).join(" && ");
  change("package.json", beforePackage, JSON.stringify(pkg, null, 2) + "\n");

  const beforeVite = await read("vite.config.js");
  let vite = beforeVite;
  const proxy = '"/api/virtual-try-on": { target: "http://127.0.0.1:3001", changeOrigin: false }';
  if (!vite.includes("/api/virtual-try-on")) {
    if (/\bproxy\s*:\s*\{/.test(vite)) vite = vite.replace(/\bproxy\s*:\s*\{/, `$& ${proxy},`);
    else if (/\bserver\s*:\s*\{/.test(vite)) vite = vite.replace(/\bserver\s*:\s*\{/, `$& proxy: { ${proxy} },`);
    else if (/defineConfig\(\s*\{/.test(vite)) vite = vite.replace(/defineConfig\(\s*\{/, `$&\n  server: { proxy: { ${proxy} } },`);
    else throw new Error("vite.config.js uses a custom format. Add the proxy shown in the setup guide manually.");
  }
  change("vite.config.js", beforeVite, vite);

  const beforeVercel = await read("vercel.json", true), vercel = beforeVercel ? JSON.parse(beforeVercel) : {};
  if (vercel.routes) throw new Error("vercel.json uses legacy routes. Merge the API settings from the setup guide manually; no files have been changed.");
  vercel.$schema ||= "https://openapi.vercel.sh/vercel.json";
  vercel.functions ||= {};
  const fn = vercel.functions["api/virtual-try-on.js"] ||= {};
  fn.maxDuration = Math.max(Number(fn.maxDuration) || 0, 60);
  const files = "config/virtual-try-on.json,public/tryon-products/**";
  if (!fn.includeFiles) fn.includeFiles = `{${files}}`;
  else if (!fn.includeFiles.includes("config/virtual-try-on.json") || !fn.includeFiles.includes("public/tryon-products/**")) fn.includeFiles = `{${fn.includeFiles},${files}}`;
  if (!vercel.rewrites?.length) vercel.rewrites = [{ source: "/((?!api/).*)", destination: "/index.html" }];
  change("vercel.json", beforeVercel, JSON.stringify(vercel, null, 2) + "\n");

  const beforeIgnore = await read(".gitignore", true);
  let ignore = beforeIgnore || "";
  for (const entry of [".env", ".env.local", "vto-backup/", "public/vto-assets/wasm/", "public/vto-assets/vision_bundle.js", "public/vto-assets/MEDIAPIPE-README.md", "public/vto-assets/pose_landmarker_lite.task", "public/vto-assets/*.tmp"])
    if (!ignore.split(/\r?\n/).includes(entry)) ignore += `${ignore.endsWith("\n") || !ignore ? "" : "\n"}${entry}\n`;
  change(".gitignore", beforeIgnore, ignore);

  if (!edits.length) { console.log("Virtual Try-On integration is already installed."); process.exit(0); }
  const backup = path.join(root, "vto-backup", new Date().toISOString().replace(/[:.]/g, "-"));
  for (const edit of edits) {
    if (edit.before === null) continue;
    const destination = path.join(backup, edit.name);
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(destination, edit.before);
  }
  await fs.mkdir(backup, { recursive: true });
  await fs.writeFile(path.join(backup, "manifest.json"), JSON.stringify({ changed: edits.map(({ name, before }) => ({ name, existed: before !== null })) }, null, 2));
  for (const edit of edits) await fs.writeFile(path.join(root, edit.name), edit.after);
  console.log(`Updated: ${edits.map(e => e.name).join(", ")}`);
  console.log(`Original files saved in ${path.relative(root, backup)}.`);
  console.log("Next: npm install, npm run setup:vto, then npm run dev:vto.");
} catch (error) {
  console.error(`Virtual Try-On integration: ${error.message}`);
  process.exitCode = 1;
}
