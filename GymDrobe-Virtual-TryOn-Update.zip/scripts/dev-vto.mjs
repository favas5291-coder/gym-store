import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes } from "node:crypto";
import { createServer } from "vite";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(root);
try {
  process.loadEnvFile(path.join(root, ".env"));
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
process.env.VTO_SESSION_SECRET ||= randomBytes(32).toString("hex");
const { createRuntime } = await import("../server/virtual-try-on/runtime.mjs");
const handler = await createRuntime({ local: true });
const server = http.createServer(handler);
await new Promise((resolve, reject) => {
  server.on("error", reject);
  server.listen(3001, "127.0.0.1", resolve);
});
const vite = await createServer({
  root,
  server: {
    host: "localhost",
    port: 5173,
    strictPort: true,
    proxy: {
      "/api/virtual-try-on": {
        target: "http://127.0.0.1:3001",
        changeOrigin: false,
      },
    },
  },
});
await vite.listen();
console.log("GymDrobe + Virtual Try-On: http://localhost:5173");
const close = async () => {
  await vite.close();
  server.close(() => process.exit(0));
};
process.on("SIGINT", close);
process.on("SIGTERM", close);
